#include "FRenderer.h"

FRenderer::FRenderer()
{

}

FRenderer::~FRenderer()
{

}