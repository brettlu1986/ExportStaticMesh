#pragma once
#include "FDynamicRHI.h"

extern bool RHICreate();

extern void RHIInit();

extern void RHIExit();